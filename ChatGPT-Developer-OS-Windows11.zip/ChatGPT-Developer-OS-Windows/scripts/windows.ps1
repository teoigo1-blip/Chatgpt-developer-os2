$ErrorActionPreference = 'Stop'
$base = Split-Path $PSScriptRoot -Parent
$transcribing = $false
function Wsl([string[]]$Arguments) {
    & wsl.exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "WSL fallo ($LASTEXITCODE). Consulta el registro." }
}
try {
    if ($base.StartsWith('\\')) { throw 'Extrae el ZIP en una carpeta local, por ejemplo C:\DeveloperOS.' }
    if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64') { throw 'Este paquete requiere Windows 11 x64 (Intel/AMD).' }
    if ([Environment]::OSVersion.Version.Build -lt 22000) { throw 'Se requiere Windows 11.' }
    New-Item -ItemType Directory -Force "$base\logs", "$base\salida" | Out-Null
    Start-Transcript -Path "$base\logs\windows-$(Get-Date -Format yyyyMMdd-HHmmss).log" | Out-Null
    $transcribing = $true
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $admin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    # Elevate only the feature setup; distro registration/build stay in the original user's account.
    & wsl.exe --status
    $ready = $LASTEXITCODE -eq 0
    if (-not $ready) {
        Write-Host 'Preparando WSL2. Windows solicitara permisos de administrador.'
        $setup = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + "$PSScriptRoot\setup-wsl.ps1" + '"'))
        if ($setup.ExitCode -ne 0 -and $setup.ExitCode -ne 3010) { throw 'No se pudo preparar WSL. Comprueba virtualizacion en BIOS/UEFI y el registro setup-wsl.' }
        Write-Host 'GUARDA TU TRABAJO Y REINICIA WINDOWS. Despues vuelve a pulsar CREAR-ISO.bat en esta misma carpeta. No se reinicia automaticamente.'
        exit 10
    }
    $distros = ((& wsl.exe --list --quiet) -join "`n") -replace "`0",''
    if ($LASTEXITCODE -ne 0) { throw 'No se pudieron consultar las distribuciones WSL.' }
    if ('Debian' -notin @($distros -split "`n" | ForEach-Object { $_.Trim() })) {
        Wsl -Arguments @('--install','--distribution','Debian','--no-launch','--web-download')
    }
    Wsl -Arguments @('--set-version','Debian','2')
    $linuxBase = (& wsl.exe -d Debian -u root -- wslpath -u $base | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $linuxBase.StartsWith('/')) { throw 'Debian no inicia. Reinicia Windows y repite. Si Debian pide crear usuario, completa ese paso.' }
    # Feed a base64 encoded path: no shell interpolation of Windows folder names.
    $encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($linuxBase))
    $command = 'p=$(printf %s ' + $encoded + ' | base64 -d); exec bash "$p/scripts/build-linux.sh" "$p"'
    if ($PSVersionTable.PSVersion.Major -le 5) { $command = $command.Replace('"','\"') }
    Wsl -Arguments @('-d','Debian','-u','root','--','bash','-lc',$command)
    Write-Host "FINALIZADO: ISO e informes en $base\salida. Arranque real y persistencia requieren pruebas aparte."
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    if ($transcribing) { Stop-Transcript | Out-Null }
}
