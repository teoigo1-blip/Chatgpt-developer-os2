$ErrorActionPreference = 'Stop'
try {
    Start-Transcript -Path (Join-Path (Split-Path $PSScriptRoot -Parent) 'logs\setup-wsl.log') -Append | Out-Null
    foreach ($feature in 'Microsoft-Windows-Subsystem-Linux','VirtualMachinePlatform') {
        Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart | Out-Null
    }
    & wsl.exe --install --no-distribution --web-download
    if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne 3010) { throw "Instalacion WSL fallo: $LASTEXITCODE" }
    exit 3010
} catch { Write-Host $_; exit 1 } finally { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
