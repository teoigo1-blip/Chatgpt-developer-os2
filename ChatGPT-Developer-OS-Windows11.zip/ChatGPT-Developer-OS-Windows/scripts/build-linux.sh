#!/usr/bin/env bash
set -Eeuo pipefail
base=${1:?Missing package folder}
mkdir -p "$base/logs" "$base/salida"
run=$(date -u +%Y%m%dT%H%M%SZ)-$$
exec > >(tee -a "$base/logs/linux-$run.log") 2>&1
trap 'code=$?; echo "ERROR $code linea $LINENO. No se declara una ISO terminada. Consulta logs. Trabajo Linux: ${work:-sin crear}"; exit "$code"' ERR
[[ $EUID == 0 && $(uname -m) == x86_64 ]] || { echo 'Requiere root y x86_64'; exit 2; }
grep -qi microsoft /proc/sys/kernel/osrelease
[[ $(uname -r) == *WSL2* || $(uname -r) == *wsl2* ]] || { echo 'Se requiere WSL2'; exit 2; }
. /etc/os-release
[[ $ID == debian ]] || { echo 'Se requiere Debian'; exit 2; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y live-build debootstrap xorriso squashfs-tools syslinux-common isolinux grub-pc-bin grub-efi-amd64-bin mtools dosfstools file python3 ca-certificates rsync util-linux
mkdir -p /var/tmp/chatgpt-developer-os
exec 9>/var/tmp/chatgpt-developer-os/build.lock
flock -n 9 || { echo 'Ya hay otra compilacion en curso'; exit 2; }
work=$(mktemp -d /var/tmp/chatgpt-developer-os/build-XXXXXXXX)
echo "Trabajo en ext4 de WSL: $work"
space=$(df -Pk "$work" | awk 'NR==2 {print $4}')
(( space >= 41943040 )) || { echo 'Necesitas al menos 40 GiB libres en WSL y espacio para la ISO en Windows'; exit 2; }
rsync -a --exclude __pycache__ --exclude '*.pyc' "$base/source/" "$work/"
cd "$work"
find . -type f \( -name '*.sh' -o -name '*.py' -o -name '*.chroot' -o -path './config/includes.chroot/usr/local/bin/*' \) -exec sed -i 's/\r$//' {} +
find . -type f -name '*.sh' -exec chmod 755 {} +
find config/hooks config/includes.chroot/usr/local/bin -type f -exec chmod 755 {} +
test -s config/package-lists/developer.list.chroot
python3 check-build-inputs.py
python3 check-target-packages.py
while IFS= read -r -d '' script; do bash -n "$script"; done < <(find . -name '*.sh' -print0)
bash verify-boot-config.sh
bash build.sh
mapfile -d '' images < <(find . -maxdepth 1 -type f -name '*.iso' -print0)
(( ${#images[@]} == 1 )) || { echo 'Se esperaba exactamente una ISO nueva'; exit 3; }
iso=$(realpath "${images[0]}")
bash verify-iso.sh "$iso"
xorriso -indev "$iso" -report_el_torito plain > boot-report.txt 2>&1
grep -Eq 'BIOS' boot-report.txt
grep -Eq 'UEFI' boot-report.txt
xorriso -indev "$iso" -ls /live/filesystem.squashfs /live/vmlinuz /live/initrd.img > live-files.txt 2>&1
out="$base/salida/$run"
mkdir -p "$out"
cp "$iso" "$out/chatgpt-developer-os-amd64.iso.partial"
expected=$(sha256sum "$iso" | cut -d' ' -f1)
actual=$(sha256sum "$out/chatgpt-developer-os-amd64.iso.partial" | cut -d' ' -f1)
[[ $expected == "$actual" ]]
mv "$out/chatgpt-developer-os-amd64.iso.partial" "$out/chatgpt-developer-os-amd64.iso"
cp boot-report.txt live-files.txt "$out/"
printf '%s  chatgpt-developer-os-amd64.iso\n' "$expected" > "$out/SHA256SUMS"
(cd "$out" && sha256sum -c SHA256SUMS)
printf 'ISO construida; verificacion estatica BIOS/UEFI y copia SHA256 correcta.\nArranque real, escritorio, persistencia y Secure Boot: NO PROBADOS.\n' > "$out/RESULTADO.txt"
echo "ISO construida y copiada: $out. Trabajo conservado: $work"
