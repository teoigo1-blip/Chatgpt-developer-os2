@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows.ps1"
set "result=%errorlevel%"
echo.
if not "%result%"=="0" echo Proceso detenido. Consulta logs y las instrucciones mostradas.
pause
exit /b %result%
